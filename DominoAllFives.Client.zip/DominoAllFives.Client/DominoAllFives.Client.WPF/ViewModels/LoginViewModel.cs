using System;
using System.ServiceModel;
using System.Windows.Controls;
using DominoAllFives.Client.WPF.Commands;
using DominoAllFives.Client.WPF.Localization;
using DominoAllFives.Client.WPF.Models;
using DominoAllFives.Client.WPF.Services;
using DominoAllFives.Client.WPF.Services.Wcf.Interfaces;
using DominoAllFives.Client.WPF.ViewModels.Base;
using DominoAllFivesService;
using Microsoft.Extensions.Logging;

namespace DominoAllFives.Client.WPF.ViewModels
{
    public class LoginViewModel : ViewModelBase
    {
        private IDialogService _dialogService;
        private ILoginClient _loginClient;
        private readonly PlayerSession _playerSession;
        private ILogger<LoginViewModel> _logger;
        private LanguageManager _languageManager;
        private readonly Action _onLoginSuccess;
        private readonly Action _onCancel;
        private readonly Action _onGoToRegister;
        private readonly Action _onGoToRecover;
        private string _email;
        private string _password;
        private bool _isEmailRequiredVisible;
        private bool _isPasswordRequiredVisible;
        public string Email { get => _email; set => SetProperty(ref _email, value); }
        public string Password { get => _password; set => SetProperty(ref _password, value); }
        public bool IsEmailRequiredVisible { get =>
            _isEmailRequiredVisible; set =>
            SetProperty(
            ref _isEmailRequiredVisible,
            value); }
        public bool IsPasswordRequiredVisible { get =>
            _isPasswordRequiredVisible; set =>
            SetProperty(
            ref _isPasswordRequiredVisible,
            value); }
        public RelayCommand LoginCommand { get; }
        public RelayCommand CancelCommand { get; }
        public RelayCommand GoToRegisterCommand { get; }
        public RelayCommand GoToRecoverCommand { get; }

        public LoginViewModel(
            PlayerSession playerSession,
            Action onLoginSuccess,
            Action onCancel,
            Action onGoToRegister,
            Action onGoToRecover)
        {
            _playerSession = playerSession ?? throw new ArgumentNullException(
                nameof(
                playerSession));
            _onLoginSuccess = onLoginSuccess ?? throw new ArgumentNullException(
                nameof(
                onLoginSuccess));
            _onCancel = onCancel ?? throw new ArgumentNullException(nameof(onCancel));
            _onGoToRegister = onGoToRegister ?? throw new ArgumentNullException(
                nameof(
                onGoToRegister));
            _onGoToRecover = onGoToRecover ?? throw new ArgumentNullException(
                nameof(
                onGoToRecover));
            _email = string.Empty;
            _password = string.Empty;
            _isEmailRequiredVisible = false;
            _isPasswordRequiredVisible = false;
            LoginCommand = new RelayCommand(ExecuteLogin);
            CancelCommand = new RelayCommand(_onCancel);
            GoToRegisterCommand = new RelayCommand(_onGoToRegister, () => false);
            GoToRecoverCommand = new RelayCommand(_onGoToRecover, () => false);
        }

        public void Initialize(
            IDialogService dialogService,
            ILoginClient loginClient,
            ILogger<LoginViewModel> logger,
            LanguageManager languageManager =
            null)
        {
            if (_loginClient != null)
            {
                throw new InvalidOperationException("LoginViewModel has already been initialized.");
            }

            _dialogService = dialogService ?? throw new ArgumentNullException(
                nameof(
                dialogService));
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            _languageManager = languageManager ?? LanguageManager.Instance;
            _loginClient = loginClient ?? throw new ArgumentNullException(nameof(loginClient));
        }

        private void ExecuteLogin(object parameter)
        {
            if (_loginClient == null)
            {
                throw new InvalidOperationException(
                    "LoginViewModel must be initialized before login.");
            }

            if (parameter is PasswordBox passwordBox)
            {
                Password = passwordBox.Password;
            }

            if (!ValidateInput())
            {
                return;
            }

            _logger.LogInformation("Attempting login for user: {EmailOrUsername}", Email.Trim());
            PlayerAccount authenticatedAccount;
            try
            {
                Credentials credentials = new Credentials
                {
                    EmailOrUsername = Email.Trim(),
                    Password = Password
                };
                authenticatedAccount = _loginClient.LoginWithAccount(credentials);
            }
            catch (FaultException<AccountIssue> ex)
            {
                _logger.LogWarning(ex, "Login rejected. Account issue: {AccountIssue}.", ex.Detail);
                ShowMessageFailure(ex.Detail);
                return;
            }
            catch (FaultException ex)
            {
                _logger.LogError(ex, "Authentication service could not complete login.");
                ShowMessageFailure();
                return;
            }
            catch (TimeoutException ex)
            {
                _logger.LogError(ex, "Authentication service timed out.");
                ShowMessageFailure(connectionFailure: true);
                return;
            }
            catch (CommunicationException ex)
            {
                _logger.LogError(ex, "Authentication service unavailable.");
                ShowMessageFailure(connectionFailure: true);
                return;
            }

            if (authenticatedAccount == null
                || authenticatedAccount.PlayerId <= 0
                || string.IsNullOrWhiteSpace(
                authenticatedAccount.Username)
                || string.IsNullOrWhiteSpace(
                authenticatedAccount.SessionKey))
            {
                _logger.LogError("Authentication service returned an invalid account.");
                ShowMessageFailure();
                return;
            }

            _languageManager.ApplyAccountLanguage(authenticatedAccount.PreferredLanguageId);
            if (_languageManager.CurrentLanguageCode != authenticatedAccount.PreferredLanguageId)
            {
                _logger.LogWarning(
                    "Unsupported stored account language "
                        + "{PreferredLanguageId}; using fallback.",
                    authenticatedAccount.PreferredLanguageId);
            }

            _playerSession.Start(
                authenticatedAccount.PlayerId,
                authenticatedAccount.Username,
                authenticatedAccount.PreferredLanguageId,
                authenticatedAccount.SessionKey);
            _logger.LogInformation(
                "User {EmailOrUsername} logged in successfully with " + "PlayerId: {PlayerId}",
                Email.Trim(),
                authenticatedAccount.PlayerId);
            _onLoginSuccess.Invoke();
        }

        private bool ValidateInput()
        {
            IsEmailRequiredVisible = string.IsNullOrWhiteSpace(Email);
            IsPasswordRequiredVisible = string.IsNullOrWhiteSpace(Password);
            return !IsEmailRequiredVisible && !IsPasswordRequiredVisible;
        }

        private void ShowMessageFailure(AccountIssue? issue = null, bool connectionFailure = false)
        {
            switch (issue)
            {
                case AccountIssue.Banned:
                    _dialogService.ShowDialog(
                        new DialogRequest {
                            Type = DialogType.Warning,
                            TitleKey = "MessageAuthentication_msgBannedAccountTitle",
                            MessageKey = "MessageAuthentication_msgBannedAccount" });
                    break;
                case AccountIssue.Suspended:
                    _dialogService.ShowDialog(
                        new DialogRequest {
                            Type = DialogType.Warning,
                            TitleKey = "MessageAuthentication_msgSuspendedAccountTitle",
                            MessageKey = "MessageAuthentication_msgSuspendedAccount" });
                    break;
                case AccountIssue.InvalidCredentials:
                    _dialogService.ShowDialog(
                        new DialogRequest {
                            Type = DialogType.Warning,
                            TitleKey = "MessageAuthentication_msgInvalidCredentialsTitle",
                            MessageKey = "MessageAuthentication_msgInvalidCredentials" });
                    break;
                case null when connectionFailure:
                    _dialogService.ShowDialog(
                        new DialogRequest {
                            Type = DialogType.Error,
                            TitleKey = "Global_msgConnectionErrorTitle",
                            MessageKey = "MessageAuthentication_msgConnectionError" });
                    break;
                default:
                    _dialogService.ShowDialog(
                        new DialogRequest {
                            Type = DialogType.Error,
                            TitleKey = "Global_msgDefaultErrorTitle",
                            MessageKey = "Global_msgDefaultError" });
                    break;
            }
        }
    }
}
